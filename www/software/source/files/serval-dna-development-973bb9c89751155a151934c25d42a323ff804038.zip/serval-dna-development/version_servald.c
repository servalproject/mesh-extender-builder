#ifndef SERVALD_VERSION
#error "SERVALD_VERSION is not defined"
#endif

const char version_servald[] = SERVALD_VERSION;
