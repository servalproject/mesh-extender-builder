#ifndef crypto_uint16_h
#define crypto_uint16_h

typedef unsigned short crypto_uint16;

#endif
