#ifndef crypto_uint8_h
#define crypto_uint8_h

typedef unsigned char crypto_uint8;

#endif
