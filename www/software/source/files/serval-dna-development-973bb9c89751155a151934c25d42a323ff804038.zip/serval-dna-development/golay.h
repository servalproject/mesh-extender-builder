int golay_encode(unsigned char *data);
int golay_decode(int *errs, unsigned char *data);
