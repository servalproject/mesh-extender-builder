/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "1.4.36"
#define ASTERISK_VERSION_NUM 10436

