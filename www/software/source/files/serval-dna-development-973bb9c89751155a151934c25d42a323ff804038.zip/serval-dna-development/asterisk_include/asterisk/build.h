/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "Serval-MBP.local"
#define BUILD_KERNEL "10.4.0"
#define BUILD_MACHINE "i386"
#define BUILD_OS "Darwin"
#define BUILD_DATE "2010-10-23 05:40:08 UTC"
#define BUILD_USER "gardners"

