/*
Serval DNA Rhizome HTTP external interface
Copyright (C) 2013 Serval Project, Inc.
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#ifdef HAVE_SYS_FILIO_H
# include <sys/filio.h>
#endif
#include <assert.h>

#include "serval.h"
#include "overlay_address.h"
#include "conf.h"
#include "str.h"
#include "strbuf_helpers.h"
#include "rhizome.h"
#include "http_server.h"

#define RHIZOME_SERVER_MAX_LIVE_REQUESTS 32

typedef int HTTP_HANDLER(rhizome_http_request *r, const char *remainder);

struct http_handler{
  const char *path;
  HTTP_HANDLER *parser;
};

static HTTP_HANDLER restful_rhizome_bundlelist_json;

static HTTP_HANDLER rhizome_status_page;
static HTTP_HANDLER rhizome_file_page;
static HTTP_HANDLER manifest_by_prefix_page;
static HTTP_HANDLER interface_page;
static HTTP_HANDLER neighbour_page;
static HTTP_HANDLER fav_icon_header;
static HTTP_HANDLER root_page;

extern HTTP_HANDLER rhizome_direct_import;
extern HTTP_HANDLER rhizome_direct_enquiry;
extern HTTP_HANDLER rhizome_direct_dispatch;

struct http_handler paths[]={
  {"/restful/rhizome/bundlelist.json", restful_rhizome_bundlelist_json},
  {"/rhizome/status", rhizome_status_page},
  {"/rhizome/file/", rhizome_file_page},
  {"/rhizome/import", rhizome_direct_import},
  {"/rhizome/enquiry", rhizome_direct_enquiry},
  {"/rhizome/manifestbyprefix/", manifest_by_prefix_page},
  {"/rhizome/", rhizome_direct_dispatch},
  {"/interface/", interface_page},
  {"/neighbour/", neighbour_page},
  {"/favicon.ico", fav_icon_header},
  {"/", root_page},
};

static int rhizome_dispatch(struct http_request *hr)
{
  rhizome_http_request *r = (rhizome_http_request *) hr;
  INFOF("RHIZOME HTTP SERVER, %s %s", r->http.verb, r->http.path);
  r->http.response.content_generator = NULL;
  unsigned i;
  for (i = 0; i < NELS(paths); ++i) {
    const char *remainder;
    if (str_startswith(r->http.path, paths[i].path, &remainder)){
      int ret = paths[i].parser(r, remainder);
      if (ret < 0) {
	http_request_simple_response(&r->http, 500, NULL);
	return 0;
      }
      if (ret == 0)
	return 0;
    }
  }
  http_request_simple_response(&r->http, 404, NULL);
  return 0;
}

struct sched_ent server_alarm;
struct profile_total server_stats = {
  .name = "rhizome_server_poll",
};

/*
  HTTP server and client code for rhizome transfers and rhizome direct.
  Selection of either use is made when starting the HTTP server and
  specifying the call-back function to use on client connections. 
 */

uint16_t rhizome_http_server_port = 0;
static int rhizome_server_socket = -1;
static int request_count=0;
static time_ms_t rhizome_server_last_start_attempt = -1;

// Format icon data using:
//   od -vt u1 ~/Downloads/favicon.ico | cut -c9- | sed 's/  */,/g'
unsigned char favicon_bytes[]={
0,0,1,0,1,0,16,16,16,0,0,0,0,0,40,1
,0,0,22,0,0,0,40,0,0,0,16,0,0,0,32,0
,0,0,1,0,4,0,0,0,0,0,128,0,0,0,0,0
,0,0,0,0,0,0,16,0,0,0,0,0,0,0,104,158
,168,0,163,233,247,0,104,161,118,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,17,17
,17,17,17,18,34,17,17,18,34,17,17,18,34,17,17,2
,34,17,17,18,34,17,16,18,34,1,17,17,1,17,1,17
,1,16,1,16,17,17,17,17,1,17,16,16,17,17,17,17
,1,17,18,34,17,17,17,16,17,17,2,34,17,17,17,16
,17,16,18,34,17,17,17,16,17,1,17,1,17,17,17,18
,34,17,17,16,17,17,17,18,34,17,17,18,34,17,17,18
,34,17,17,18,34,17,17,16,17,17,17,18,34,17,17,16
,17,17,17,17,17,0,17,1,17,17,17,17,17,17,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int favicon_len=318;

int is_rhizome_http_server_running()
{
  return rhizome_server_socket != -1;
}

/* Start the Rhizome HTTP server by creating a socket, binding it to an available port, and
   marking it as passive.  If called repeatedly and frequently, this function will only try to start
   the server after a certain time has elapsed since the last attempt.
   Return -1 if an error occurs (message logged).
   Return 0 if the server was started.
   Return 1 if the server is already started successfully.
   Return 2 if the server was not started because it is too soon since last failed attempt.
 */
int rhizome_http_server_start(uint16_t port_low, uint16_t port_high)
{
  if (rhizome_server_socket != -1)
    return 1;

  /* Only try to start http server every five seconds. */
  time_ms_t now = gettime_ms();
  if (now < rhizome_server_last_start_attempt + 5000)
    return 2;
  rhizome_server_last_start_attempt  = now;
  if (config.debug.rhizome_httpd)
    DEBUGF("Starting rhizome HTTP server");

  uint16_t port;
  for (port = port_low; port <= port_high; ++port) {
    /* Create a new socket, reusable and non-blocking. */
    if (rhizome_server_socket == -1) {
      rhizome_server_socket = socket(AF_INET,SOCK_STREAM,0);
      if (rhizome_server_socket == -1) {
	WHY_perror("socket");
	goto error;
      }
      int on=1;
      if (setsockopt(rhizome_server_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1) {
	WHY_perror("setsockopt(REUSEADDR)");
	goto error;
      }
      if (ioctl(rhizome_server_socket, FIONBIO, (char *)&on) == -1) {
	WHY_perror("ioctl(FIONBIO)");
	goto error;
      }
    }
    /* Bind it to the next port we want to try. */
    struct sockaddr_in address;
    bzero((char *) &address, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port);
    if (bind(rhizome_server_socket, (struct sockaddr *) &address, sizeof(address)) == -1) {
      if (errno != EADDRINUSE) {
	WHY_perror("bind");
	goto error;
      }
    } else {
      /* We bound to a port.  The battle is half won.  Now we have to successfully listen on that
	port, which could also fail with EADDRINUSE, in which case we have to scrap the socket and
	create a new one, because once bound, a socket stays bound.
      */
      if (listen(rhizome_server_socket, 20) != -1)
	goto success;
      if (errno != EADDRINUSE) {
	WHY_perror("listen");
	goto error;
      }
      close(rhizome_server_socket);
      rhizome_server_socket = -1;
    }
  }
  WHYF("No ports available in range %u to %u", RHIZOME_HTTP_PORT, RHIZOME_HTTP_PORT_MAX);
error:
  if (rhizome_server_socket != -1) {
    close(rhizome_server_socket);
    rhizome_server_socket = -1;
  }
  return WHY("Failed to start rhizome HTTP server");

success:
  if (config.rhizome.http.enable)
    INFOF("RHIZOME HTTP SERVER, START port=%"PRIu16" fd=%d", port, rhizome_server_socket);
  else
    INFOF("HTTP SERVER (LIMITED SERVICE), START port=%"PRIu16" fd=%d", port, rhizome_server_socket);

  rhizome_http_server_port = port;
  /* Add Rhizome HTTPd server to list of file descriptors to watch */
  server_alarm.function = rhizome_server_poll;
  server_alarm.stats = &server_stats;
  server_alarm.poll.fd = rhizome_server_socket;
  server_alarm.poll.events = POLLIN;
  watch(&server_alarm);
  return 0;

}

static void rhizome_server_finalise_http_request(struct http_request *_r)
{
  rhizome_http_request *r = (rhizome_http_request *) _r;
  rhizome_read_close(&r->u.read_state);
  request_count--;
}

static int rhizome_dispatch(struct http_request *);

static unsigned int rhizome_http_request_uuid_counter = 0;

void rhizome_server_poll(struct sched_ent *alarm)
{
  if (alarm->poll.revents & (POLLIN | POLLOUT)) {
    struct sockaddr addr;
    unsigned int addr_len = sizeof addr;
    int sock;
    if ((sock = accept(rhizome_server_socket, &addr, &addr_len)) == -1) {
      if (errno && errno != EAGAIN)
	WARN_perror("accept");
    } else {
      struct sockaddr_in *peerip=NULL;
      if (addr.sa_family == AF_INET) {
	peerip = (struct sockaddr_in *)&addr; // network order
	INFOF("RHIZOME HTTP SERVER, ACCEPT addrlen=%u family=%u port=%u addr=%u.%u.%u.%u",
	    addr_len, peerip->sin_family, peerip->sin_port,
	    ((unsigned char*)&peerip->sin_addr.s_addr)[0],
	    ((unsigned char*)&peerip->sin_addr.s_addr)[1],
	    ((unsigned char*)&peerip->sin_addr.s_addr)[2],
	    ((unsigned char*)&peerip->sin_addr.s_addr)[3]
	  );
      } else {
	INFOF("RHIZOME HTTP SERVER, ACCEPT addrlen=%u family=%u data=%s",
	    addr_len, addr.sa_family, alloca_tohex((unsigned char *)addr.sa_data, sizeof addr.sa_data)
	  );
      }
      rhizome_http_request *request = emalloc_zero(sizeof(rhizome_http_request));
      if (request == NULL) {
	WHY("Cannot respond to HTTP request, out of memory");
	close(sock);
      } else {
	request_count++;
	request->uuid = rhizome_http_request_uuid_counter++;
	request->data_file_name[0] = '\0';
	request->u.read_state.blob_fd = -1;
	request->u.read_state.blob_rowid = -1;
	if (peerip)
	  request->http.client_sockaddr_in = *peerip;
	request->http.handle_headers = rhizome_dispatch;
	request->http.debug_flag = &config.debug.rhizome_httpd;
	request->http.disable_tx_flag = &config.debug.rhizome_nohttptx;
	request->http.finalise = rhizome_server_finalise_http_request;
	request->http.free = free;
	request->http.idle_timeout = RHIZOME_IDLE_TIMEOUT;
	http_request_init(&request->http, sock);
      }
    }
  }
  if (alarm->poll.revents & (POLLHUP | POLLERR)) {
    INFO("Error on tcp listen socket");
  }
}

int is_http_header_complete(const char *buf, size_t len, size_t read_since_last_call)
{
  IN();
  const char *bufend = buf + len;
  const char *p = buf;
  size_t tail = read_since_last_call + 4;
  if (tail < len)
    p = bufend - tail;
  int count = 0;
  for (; p != bufend; ++p) {
    switch (*p) {
      case '\n': 
	if (++count==2)
	  RETURN(p - buf);
      case '\r': // ignore CR
      case '\0': // ignore NUL (telnet inserts them)
	break;
      default: 
	count = 0; 
	break;
    }
  }
  RETURN(0);
  OUT();
}

static int is_from_loopback(const struct http_request *r)
{
  return   r->client_sockaddr_in.sin_family == AF_INET
	&& ((unsigned char*)&r->client_sockaddr_in.sin_addr.s_addr)[0] == IN_LOOPBACKNET;
}

/* Return 1 if the given authorization credentials are acceptable.
 * Return 0 if not.
 */
static int is_authorized(const struct http_client_authorization *auth)
{
  if (auth->scheme != BASIC)
    return 0;
  unsigned i;
  for (i = 0; i != config.rhizome.api.restful.users.ac; ++i) {
    if (   strcmp(config.rhizome.api.restful.users.av[i].key, auth->credentials.basic.user) == 0
	&& strcmp(config.rhizome.api.restful.users.av[i].value.password, auth->credentials.basic.password) == 0
    )
      return 1;
  }
  return 0;
}

static int authorize(struct http_request *r)
{
  if (!is_from_loopback(r)) {
    http_request_simple_response(r, 403, NULL);
    return 0;
  }
  if (!is_authorized(&r->request_header.authorization)) {
    r->response.header.www_authenticate.scheme = BASIC;
    r->response.header.www_authenticate.realm = "Serval Rhizome";
    http_request_simple_response(r, 401, NULL);
    return 0;
  }
  return 1;
}

static HTTP_CONTENT_GENERATOR restful_rhizome_bundlelist_json_content;

static int restful_rhizome_bundlelist_json(rhizome_http_request *r, const char *remainder)
{
  if (!is_rhizome_http_enabled())
    return 1;
  if (*remainder)
    return 1;
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  if (!authorize(&r->http))
    return 0;
  r->u.list.phase = LIST_HEADER;
  r->u.list.rowcount = 0;
  bzero(&r->u.list.cursor, sizeof r->u.list.cursor);
  http_request_response_generated(&r->http, 200, "application/json", restful_rhizome_bundlelist_json_content);
  return 0;
}

#define LIST_TOKEN_STRLEN_MAX (UUID_STRLEN + 30)
#define alloca_list_token(rowid) list_token(alloca(LIST_TOKEN_STRLEN_MAX), (rowid))

static char *list_token(char *buf, uint64_t rowid)
{
  strbuf b = strbuf_local(buf, LIST_TOKEN_STRLEN_MAX);
  strbuf_uuid(b, &rhizome_db_uuid);
  strbuf_sprintf(b, "-%"PRIu64, rowid);
  return buf;
}

static int restful_rhizome_bundlelist_json_content_chunk(sqlite_retry_state *retry, struct rhizome_http_request *r, strbuf b)
{
  const char *headers[] = {
    "_id",
    "service",
    "id",
    "version",
    "date",
    ".inserttime",
    ".author",
    ".fromhere",
    "filesize",
    "filehash",
    "sender",
    "recipient",
    "name"
  };
  switch (r->u.list.phase) {
    case LIST_HEADER:
      strbuf_puts(b, "{\n\"header\":[");
      unsigned i;
      for (i = 0; i != NELS(headers); ++i) {
	if (i)
	  strbuf_putc(b, ',');
	strbuf_json_string(b, headers[i]);
      }
      strbuf_puts(b, "]");
      if (!strbuf_overrun(b))
	r->u.list.phase = LIST_TOKEN;
      return 1;
    case LIST_TOKEN:
    case LIST_ROWS:
      {
	int ret = rhizome_list_next(retry, &r->u.list.cursor);
	if (ret == -1)
	  return -1;
	rhizome_manifest *m = r->u.list.cursor.manifest;
	if (r->u.list.phase == LIST_TOKEN) {
	  strbuf_puts(b, ",\n\"token\":");
	  strbuf_json_string(b, alloca_list_token(ret ? m->rowid : 0));
	  strbuf_puts(b, ",\n\"rows\":[");
	}
	if (ret == 0) {
	  strbuf_puts(b, "\n]\n}\n");
	  if (strbuf_overrun(b))
	    return 0;
	  r->u.list.phase = LIST_DONE;
	  return 0;
	}
	assert(m->filesize != RHIZOME_SIZE_UNSET);
	rhizome_lookup_author(m);
	if (r->u.list.phase != LIST_TOKEN)
	  strbuf_putc(b, ',');
	strbuf_puts(b, "\n[");
	strbuf_sprintf(b, "%"PRIu64, m->rowid);
	strbuf_putc(b, ',');
	strbuf_json_string(b, m->service);
	strbuf_putc(b, ',');
	strbuf_json_hex(b, m->cryptoSignPublic.binary, sizeof m->cryptoSignPublic.binary);
	strbuf_putc(b, ',');
	strbuf_sprintf(b, "%"PRId64, m->version);
	strbuf_putc(b, ',');
	if (m->has_date)
	  strbuf_sprintf(b, "%"PRItime_ms_t, m->date);
	else
	  strbuf_json_null(b);
	strbuf_putc(b, ',');
	strbuf_sprintf(b, "%"PRItime_ms_t",", m->inserttime);
	switch (m->authorship) {
	  case AUTHOR_LOCAL:
	  case AUTHOR_AUTHENTIC:
	    strbuf_json_hex(b, m->author.binary, sizeof m->author.binary);
	    strbuf_puts(b, ",1,");
	    break;
	  default:
	    strbuf_json_null(b);
	    strbuf_puts(b, ",1,");
	    break;
	}
	strbuf_sprintf(b, "%"PRIu64, m->filesize);
	strbuf_putc(b, ',');
	strbuf_json_hex(b, m->filesize ? m->filehash.binary : NULL, sizeof m->filehash.binary);
	strbuf_putc(b, ',');
	strbuf_json_hex(b, m->has_sender ? m->sender.binary : NULL, sizeof m->sender.binary);
	strbuf_putc(b, ',');
	strbuf_json_hex(b, m->has_recipient ? m->recipient.binary : NULL, sizeof m->recipient.binary);
	strbuf_putc(b, ',');
	strbuf_json_string(b, m->name);
	strbuf_puts(b, "]");
	if (!strbuf_overrun(b)) {
	  rhizome_list_commit(&r->u.list.cursor);
	  ++r->u.list.rowcount;
	}
	r->u.list.phase = LIST_ROWS;
	return 1;
      }
    case LIST_DONE:
      return 0;
  }
  abort();
}

static int restful_rhizome_bundlelist_json_content(struct http_request *hr, unsigned char *buf, size_t bufsz, struct http_content_generator_result *result)
{
  rhizome_http_request *r = (rhizome_http_request *) hr;
  assert(bufsz > 0);
  sqlite_retry_state retry = SQLITE_RETRY_STATE_DEFAULT;
  int ret = rhizome_list_open(&retry, &r->u.list.cursor);
  if (ret == -1)
    return -1;
  strbuf b = strbuf_local((char *)buf, bufsz);
  while ((ret = restful_rhizome_bundlelist_json_content_chunk(&retry, r, b)) != -1) {
    if (strbuf_overrun(b)) {
      if (config.debug.rhizome)
	DEBUGF("overrun by %zu bytes", strbuf_count(b) - strbuf_len(b));
      result->need = strbuf_count(b) + 1 - result->generated;
      break;
    }
    result->generated = strbuf_len(b);
    if (ret == 0)
      break;
  }
  rhizome_list_release(&r->u.list.cursor);
  return ret;
}

static int neighbour_page(rhizome_http_request *r, const char *remainder)
{
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  char buf[8*1024];
  strbuf b = strbuf_local(buf, sizeof buf);
  sid_t neighbour_sid;
  if (str_to_sid_t(&neighbour_sid, remainder) == -1)
    return 1;
  struct subscriber *neighbour = find_subscriber(neighbour_sid.binary, sizeof(neighbour_sid.binary), 0);
  if (!neighbour)
    return 1;
  strbuf_puts(b, "<html><head><meta http-equiv=\"refresh\" content=\"5\" ></head><body>");
  link_neighbour_status_html(b, neighbour);
  strbuf_puts(b, "</body></html>");
  if (strbuf_overrun(b))
    return -1;
  http_request_response_static(&r->http, 200, "text/html", buf, strbuf_len(b));
  return 0;
}

static int interface_page(rhizome_http_request *r, const char *remainder)
{
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  char buf[8*1024];
  strbuf b=strbuf_local(buf, sizeof buf);
  int index=atoi(remainder);
  if (index<0 || index>=OVERLAY_MAX_INTERFACES)
    return 1;
  strbuf_puts(b, "<html><head><meta http-equiv=\"refresh\" content=\"5\" ></head><body>");
  interface_state_html(b, &overlay_interfaces[index]);
  strbuf_puts(b, "</body></html>");
  if (strbuf_overrun(b))
    return -1;
  http_request_response_static(&r->http, 200, "text/html", buf, strbuf_len(b));
  return 0;
}

static int rhizome_status_page(rhizome_http_request *r, const char *remainder)
{
  if (!is_rhizome_http_enabled())
    return 1;
  if (*remainder)
    return 1;
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  char buf[32*1024];
  strbuf b = strbuf_local(buf, sizeof buf);
  strbuf_puts(b, "<html><head><meta http-equiv=\"refresh\" content=\"5\" ></head><body>");
  strbuf_sprintf(b, "%d HTTP requests<br>", request_count);
  strbuf_sprintf(b, "%d Bundles transferring via MDP<br>", rhizome_cache_count());
  rhizome_fetch_status_html(b);
  strbuf_puts(b, "</body></html>");
  if (strbuf_overrun(b))
    return -1;
  http_request_response_static(&r->http, 200, "text/html", buf, strbuf_len(b));
  return 0;
}

static int rhizome_file_content(struct http_request *hr, unsigned char *buf, size_t bufsz, struct http_content_generator_result *result)
{
  // Only read multiples of 4k from disk.
  const size_t blocksz = 1 << 12;
  // Ask for a large buffer for all future reads.
  const size_t preferred_bufsz = 16 * blocksz;
  // Reads the next part of the payload into the supplied buffer.
  rhizome_http_request *r = (rhizome_http_request *) hr;
  assert(r->u.read_state.offset < r->u.read_state.length);
  uint64_t remain = r->u.read_state.length - r->u.read_state.offset;
  size_t readlen = bufsz;
  if (remain < bufsz)
    readlen = remain;
  else
    readlen &= ~(blocksz - 1);
  if (readlen > 0) {
    ssize_t n = rhizome_read(&r->u.read_state, buf, readlen);
    if (n == -1)
      return -1;
    result->generated = (size_t) n;
  }
  assert(r->u.read_state.offset <= r->u.read_state.length);
  remain = r->u.read_state.length - r->u.read_state.offset;
  result->need = remain < preferred_bufsz ? remain : preferred_bufsz;
  return remain ? 1 : 0;
}

static int rhizome_file_page(rhizome_http_request *r, const char *remainder)
{
  /* Stream the specified payload */
  if (!is_rhizome_http_enabled())
    return 1;
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  if (r->http.request_header.content_range_count > 1) {
    // To support byte range sets, eg, Range: bytes=0-100,200-300,400- we would have
    // to reply with a multipart/byteranges MIME content.
    http_request_simple_response(&r->http, 501, "Not Implemented: Byte range sets");
    return 0;
  }
  rhizome_filehash_t filehash;
  if (str_to_rhizome_filehash_t(&filehash, remainder) == -1)
    return 1;
  bzero(&r->u.read_state, sizeof r->u.read_state);
  int n = rhizome_open_read(&r->u.read_state, &filehash);
  if (n == -1) {
    http_request_simple_response(&r->http, 500, NULL);
    return 0;
  }
  if (n != 0)
    return 1;
  if (r->u.read_state.length == -1 && rhizome_read(&r->u.read_state, NULL, 0)) {
    rhizome_read_close(&r->u.read_state);
    return 1;
  }
  assert(r->u.read_state.length != -1);
  r->http.response.header.resource_length = r->u.read_state.length;
  if (r->http.request_header.content_range_count > 0) {
    assert(r->http.request_header.content_range_count == 1);
    struct http_range closed;
    unsigned n = http_range_close(&closed, r->http.request_header.content_ranges, 1, r->u.read_state.length);
    if (n == 0 || http_range_bytes(&closed, 1) == 0) {
      http_request_simple_response(&r->http, 416, NULL); // Request Range Not Satisfiable
      return 0;
    }
    r->http.response.header.content_range_start = closed.first;
    r->http.response.header.content_length = closed.last - closed.first + 1;
    r->u.read_state.offset = closed.first;
  } else {
    r->http.response.header.content_range_start = 0;
    r->http.response.header.content_length = r->http.response.header.resource_length;
    r->u.read_state.offset = 0;
  }
  http_request_response_generated(&r->http, 200, "application/binary", rhizome_file_content);
  return 0;
}

static int manifest_by_prefix_page(rhizome_http_request *r, const char *remainder)
{
  if (!is_rhizome_http_enabled())
    return 1;
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  rhizome_bid_t prefix;
  const char *endp = NULL;
  unsigned prefix_len = strn_fromhex(prefix.binary, sizeof prefix.binary, remainder, &endp);
  if (endp == NULL || *endp != '\0' || prefix_len < 1)
    return 1; // not found
  rhizome_manifest *m = rhizome_new_manifest();
  int ret = rhizome_retrieve_manifest_by_prefix(prefix.binary, prefix_len, m);
  if (ret == -1)
    http_request_simple_response(&r->http, 500, NULL);
  else if (ret == 0)
    http_request_response_static(&r->http, 200, "application/binary", (const char *)m->manifestdata, m->manifest_all_bytes);
  rhizome_manifest_free(m);
  return ret <= 0 ? 0 : 1;
}

static int fav_icon_header(rhizome_http_request *r, const char *remainder)
{
  if (*remainder)
    return 1;
  http_request_response_static(&r->http, 200, "image/vnd.microsoft.icon", (const char *)favicon_bytes, favicon_len);
  return 0;
}

static int root_page(rhizome_http_request *r, const char *remainder)
{
  if (*remainder)
    return 1;
  if (r->http.verb != HTTP_VERB_GET) {
    http_request_simple_response(&r->http, 405, NULL);
    return 0;
  }
  char temp[8192];
  strbuf b = strbuf_local(temp, sizeof temp);
  strbuf_sprintf(b, "<html><head><meta http-equiv=\"refresh\" content=\"5\" ></head><body>"
	   "<h1>Hello, I'm %s*</h1><br>"
	   "Interfaces;<br>",
	   alloca_tohex_sid_t_trunc(my_subscriber->sid, 16));
  int i;
  for (i=0;i<OVERLAY_MAX_INTERFACES;i++){
    if (overlay_interfaces[i].state==INTERFACE_STATE_UP)
      strbuf_sprintf(b, "<a href=\"/interface/%d\">%d: %s, TX: %d, RX: %d</a><br>",
	i, i, overlay_interfaces[i].name, overlay_interfaces[i].tx_count, overlay_interfaces[i].recv_count);
  }
  strbuf_puts(b, "Neighbours;<br>");
  link_neighbour_short_status_html(b, "/neighbour");
  if (is_rhizome_http_enabled()){
    strbuf_puts(b, "<a href=\"/rhizome/status\">Rhizome Status</a><br>");
  }
  strbuf_puts(b, "</body></html>");
  if (strbuf_overrun(b)) {
    WHY("HTTP Root page buffer overrun");
    http_request_simple_response(&r->http, 500, NULL);
  } else
    http_request_response_static(&r->http, 200, "text/html", temp, strbuf_len(b));
  return 0;
}
