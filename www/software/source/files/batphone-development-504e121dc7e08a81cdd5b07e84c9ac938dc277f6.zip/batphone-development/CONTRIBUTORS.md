Serval Mesh Contributors
========================
[Serval Project][], January 2013

The following individuals have contributed to the [Serval Mesh][] software.  We
apologise for any omissions.  If you know of a name that is missing, please
contact us.

Serval Project team
-------------------
 * Dr Paul Gardner-Stephen, Co-founder and Project Lead
 * Romana Challans, Co-founder and UI/UX Lead
 * Jennifer Hampton, Project Manager
 * Corey Wallis, Software Engineer, [Serval Maps][]
 * Jeremy Lakeman, Senior Software Engineer
 * Andrew Bettison, Senior Software Engineer
 * Daniel O'Connor, Senior Software Engineer
 * Lyn Stephens, Tester and Hardware Engineer
 * Brendon Kelly, Software and UI Engineer

Students
--------
 * Luke Marshall – 3rd year, 2012
 * Kyle Blake – 2nd year, 2012
 * Romain Bochet – Honours, 2011
 * Thomas Giraud – Honours, 2011
 * Swapna Palaniswamy – Masters, 2011
 * Dany Rakotopara – Masters, 2010

Other contributors
------------------
 * Romain Vimont (®om)
 * Rob Thomas


[Serval Project]: http://www.servalproject.org/
[Serval Mesh]: https://play.google.com/store/apps/details?id=org.servalproject
[Serval Maps]: http://developer.servalproject.org/dokuwiki/doku.php?id=content:servalmaps:main_page
